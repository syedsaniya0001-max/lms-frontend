import React from 'react';
import { useNavigate } from 'react-router-dom';

const StudentBooks = () => {
  const navigate = useNavigate();

  const books = [
    { title: "The Hobbit", author: "J.R.R. Tolkien", isbn: "9780261102217", image: "https://covers.openlibrary.org/b/id/6979861-S.jpg", available: true },
    { title: "1984", author: "George Orwell", isbn: "9780451524935", image: "https://covers.openlibrary.org/b/id/7222246-S.jpg", available: false },
    { title: "Pride and Prejudice", author: "Jane Austen", isbn: "9780141439518", image: "https://covers.openlibrary.org/b/id/8231856-S.jpg", available: true },
    { title: "To Kill a Mockingbird", author: "Harper Lee", isbn: "9780060935467", image: "https://covers.openlibrary.org/b/id/8228691-S.jpg", available: false },
    { title: "The Great Gatsby", author: "F. Scott Fitzgerald", isbn: "9780743273565", image: "https://covers.openlibrary.org/b/id/7222276-S.jpg", available: true },
    { title: "The Catcher in the Rye", author: "J.D. Salinger", isbn: "9780316769488", image: "https://covers.openlibrary.org/b/id/8235087-S.jpg", available: true },
    { title: "Moby-Dick", author: "Herman Melville", isbn: "9780142437247", image: "https://covers.openlibrary.org/b/id/8100928-S.jpg", available: false },
    { title: "Brave New World", author: "Aldous Huxley", isbn: "9780060850524", image: "https://covers.openlibrary.org/b/id/7222171-S.jpg", available: true },
    { title: "The Lord of the Rings", author: "J.R.R. Tolkien", isbn: "9780261102385", image: "https://covers.openlibrary.org/b/id/8114151-S.jpg", available: true }
  ];

  const handleRequest = (title) => {
    alert("Request sent for: " + title);
  };

  const styles = `
    .books-page { font-family: Arial, sans-serif; background: #1e40af; min-height: 100vh; padding: 0; margin: 0; }
    header { background-color: black; color: white; text-align: center; padding: 20px; border: 1px solid black; margin-bottom: 20px; font-size: 40px; }
    .container { display: flex; flex-wrap: wrap; justify-content: space-around; padding: 10px; gap: 25px; }
    .card { background: white; width: 350px; margin: 10px; padding: 15px; text-align: center; border: 1px solid #ccc; border-radius: 10px; transition: 0.5s; box-sizing: border-box; }
    .card:hover { background-color: #e0e0e0; transform: scale(1.07); }
    .card img { width: 100px; height: 150px; margin-bottom: 10px; border-radius: 4px; }
    .card h4 { margin: 10px 0; color: #333; }
    .card p { color: #666; font-size: 14px; margin: 5px 0; }
    .card button { padding: 8px 15px; background-color: #1e40af; color: white; border: none; cursor: pointer; border-radius: 4px; transition: 0.5s; }
    .card button:hover { background-color: #1e974f; transform: scale(1.05); }
    .not-available { color: red; font-weight: bold; margin-top: 10px; }
    .back-btn { background-color: black; color: white; height: 45px; width: 100px; margin: 0 0 20px 20px; font-size: 15px; border: none; cursor: pointer; border-radius: 5px; transition: 0.3s; }
    .back-btn:hover { opacity: 0.8; }
  `;

  return (
    <div className="books-page">
      <style>{styles}</style>
      <header>Books</header>
      
      <div className="container">
        {books.map((book, index) => (
          <div key={index} className="card">
            <img src={book.image} alt={book.title} />
            <h4>{book.title}</h4>
            <p>Author: {book.author}</p>
            <p>ISBN: {book.isbn}</p>
            {book.available ? (
              <button onClick={() => handleRequest(book.title)}>Request</button>
            ) : (
              <p className="not-available">Not Available</p>
            )}
          </div>
        ))}
      </div>

      <button className="back-btn" onClick={() => navigate('/student-dashboard')}>
        Back
      </button>
    </div>
  );
};

export default StudentBooks;