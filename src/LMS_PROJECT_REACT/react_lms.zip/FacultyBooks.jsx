import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const FacultyBooks = () => {
  const navigate = useNavigate();
  
  // Book Data
  const initialBooks = [
    { name: "AI Basics", author: "John Doe", isbn: "111", available: true, location: "Floor 1, Rack A", image: "AI.jpg" },
    { name: "Data Science", author: "Jane Smith", isbn: "222", available: false, image: "Data Science.jpg" },
    { name: "Machine Learning", author: "Andrew Ng", isbn: "333", available: true, location: "Floor 2, Rack B", image: "ML.jpg" },
    { name: "Web Development", author: "David Miller", isbn: "444", available: true, location: "Floor 3, Rack C", image: "WD.jpg" },
    { name: "Python Programming", author: "Guido Rossum", isbn: "555", available: false, image: "Python.jpg" },
    { name: "Database Systems", author: "Korth", isbn: "666", available: true, location: "Floor 1, Rack D", image: "DB.jpg" },
    { name: "Computer Networks", author: "Tanenbaum", isbn: "777", available: true, location: "Floor 2, Rack E", image: "CN.jpg" },
    { name: "Operating Systems", author: "Silberschatz", isbn: "888", available: false, image: "OS.jpg" },
  ];

  const [searchTerm, setSearchTerm] = useState("");
  const [tooltip, setTooltip] = useState({ visible: false, text: "", x: 0, y: 0 });
  const [popup, setPopup] = useState({ visible: false, text: "" });

  const filteredBooks = initialBooks.filter(book => 
    book.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    book.author.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleMouseMove = (e) => {
    setTooltip(prev => ({ ...prev, x: e.pageX + 10, y: e.pageY + 10 }));
  };

  const showTooltip = (text) => setTooltip(prev => ({ ...prev, visible: true, text }));
  const hideTooltip = () => setTooltip(prev => ({ ...prev, visible: false }));

  const styles = {
    page: {
      fontFamily: 'Arial, sans-serif',
      margin: 0,
      background: '#1e40af',
      minHeight: '100vh',
      paddingBottom: '50px'
    },
    title: {
      textAlign: 'center',
      padding: '20px',
      color: 'white',
      margin: 0
    },
    searchBox: {
      textAlign: 'center',
      marginBottom: '20px',
    },
    input: {
      width: '60%',
      maxWidth: '400px',
      padding: '12px 20px',
      borderRadius: '25px',
      border: '1px solid #ccc',
      fontSize: '16px',
      outline: 'none'
    },
    container: {
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'center',
      gap: '20px', // Maintained the gap as requested
      padding: '20px',
    },
    bookCard: {
      background: 'aliceblue',
      width: '250px',
      padding: '15px',
      borderRadius: '10px',
      textAlign: 'center',
      boxShadow: '0 4px 10px rgba(0, 0, 0, 0.1)',
      transition: '0.3s',
      cursor: 'default'
    },
    cardImage: {
      width: '100%',
      height: '150px',
      objectFit: 'cover',
      borderRadius: '5px'
    },
    status: {
      color: 'red',
      fontWeight: 'bold'
    },
    location: {
      color: 'blue',
      cursor: 'pointer',
      margin: '10px 0'
    },
    btn: {
      padding: '8px 15px',
      border: 'none',
      borderRadius: '5px',
      margin: '5px',
      cursor: 'pointer',
      fontWeight: 'bold',
      fontSize: '14px'
    },
    borrowBtn: {
      background: '#1e40af',
      color: 'white'
    },
    reserveBtn: {
      background: 'green',
      color: 'white'
    },
    tooltip: {
      position: 'absolute',
      background: 'rgba(0, 0, 0, 0.85)',
      color: 'white',
      padding: '8px 12px',
      borderRadius: '8px',
      fontSize: '14px',
      display: tooltip.visible ? 'block' : 'none',
      left: `${tooltip.x}px`,
      top: `${tooltip.y}px`,
      pointerEvents: 'none',
      zIndex: 1000
    },
    popupOverlay: {
      position: 'fixed',
      top: 0,
      left: 0,
      width: '100%',
      height: '100%',
      background: 'rgba(0, 0, 0, 0.5)',
      display: popup.visible ? 'flex' : 'none',
      justifyContent: 'center',
      alignItems: 'center',
      zIndex: 2000
    },
    popupContent: {
      background: 'white',
      padding: '30px',
      borderRadius: '10px',
      textAlign: 'center',
      boxShadow: '0 5px 15px rgba(0,0,0,0.3)'
    },
    backLink: {
      display: 'block',
      textAlign: 'center',
      color: 'white',
      textDecoration: 'none',
      marginTop: '20px',
      fontSize: '18px'
    }
  };

  return (
    <div style={styles.page}>
      <h1 style={styles.title}>📚 BOOKS</h1>

      <div style={styles.searchBox}>
        <input
          type="text"
          placeholder="Search by book name or author..."
          style={styles.input}
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <div style={styles.container}>
        {filteredBooks.map((book, index) => (
          <div 
            key={index} 
            style={styles.bookCard}
            onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.05)'}
            onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
          >
            <img src={book.image} alt={book.name} style={styles.cardImage} />
            <h3 style={{ margin: '10px 0' }}>{book.name}</h3>
            <p>Author: {book.author}</p>
            <p>ISBN: {book.isbn}</p>
            
            {book.available ? (
              <>
                <p 
                  style={styles.location} 
                  onMouseEnter={() => showTooltip(book.location)}
                  onMouseLeave={hideTooltip}
                  onMouseMove={handleMouseMove}
                >
                  📍 View Location
                </p>
                <button 
                  style={{...styles.btn, ...styles.borrowBtn}}
                  onClick={() => setPopup({ visible: true, text: `You borrowed: ${book.name}` })}
                >
                  Borrow
                </button>
              </>
            ) : (
              <>
                <p style={styles.status}>Not Available</p>
                <button 
                  style={{...styles.btn, ...styles.reserveBtn}}
                  onClick={() => setPopup({ visible: true, text: `You reserved: ${book.name}` })}
                >
                  Reserve
                </button>
              </>
            )}
          </div>
        ))}
      </div>

      {/* Tooltip */}
      <div style={styles.tooltip}>{tooltip.text}</div>

      {/* Popup */}
      <div style={styles.popupOverlay}>
        <div style={styles.popupContent}>
          <p style={{ fontSize: '18px', fontWeight: 'bold' }}>{popup.text}</p>
          <button 
            style={{...styles.btn, ...styles.borrowBtn, marginTop: '10px'}}
            onClick={() => setPopup({ visible: false, text: "" })}
          >
            OK
          </button>
        </div>
      </div>

      <a href="#" style={styles.backLink} onClick={(e) => { e.preventDefault(); navigate('/faculty-dashboard'); }}>
        Go Back to Dashboard
      </a>
    </div>
  );
};

export default FacultyBooks;